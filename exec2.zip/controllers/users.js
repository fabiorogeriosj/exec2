const users = [{
  nome: 'fabio',
  email: 'fabio@fabio.com',
  id: 123
}]

const obterIndex = (id) => {
  var indexUser = null
  users.forEach((user, index) => {
    if (user.id === id) {
      indexUser = index
    }
  })
  return indexUser
}

const createItem = (user) => {
  if (!user.name) throw new Error('Informe o nome')
  user.id = new Date().getTime()
  users.push(user)
  return user
}

const getAll = () => {
  return users
}

const getItem = (id) => {
  return users.filter((user) => user.id === id)
}

const deleteItem = (id) => {
  if (!id) throw new Error('Informe o ID!')
  users.splice(obterIndex(id), 1)
  return true
}

const updateItem = (user) => {
  const index = obterIndex(user.id)
  users[index] = user
  return true
}
module.exports = {
  createItem, getAll, getItem, deleteItem, updateItem
}
