const moment = require('moment')
const express = require('express')
const bodyParser = require('body-parser')
const app = express()

const users = require('./controllers/users')

app.use(bodyParser.json())

app.get('/', (req, res) => {
  res.send('API rodando...')
})

app.get('/users', (req, res) => {
  res.json(users.getAll())
})

app.post('/users', (req, res) => {
  try {
    const user = users.createItem(req.body)
    res.json(user)
  } catch (error) {
    res.send(error.message)
  }
})

app.delete('/users', (req, res) => {
  try {
    users.deleteItem(req.body.id)
    res.send('Excluido!')
  } catch (error) {
    res.send(error.message)
  }
})

app.get('/users/:id', (req, res) => {
  const user = users.getItem(parseInt(req.params.id))
  res.json(user)
})

app.put('/users', (req, res) => {
  users.updateItem(req.body)
  res.send('Alterado!')
})

app.listen(3000, () => console.log('API rodando na porta 3000'))

// var nome = 'Fábio Rogério'
// var email = 'fabio.rogerio.sj@gmail.com'
// var dataNascimento = '1986-12-15'

// var dataFormatada = moment(dataNascimento, 'YYYY-MM-DD').format('DD/MM/YYYY')

// console.log('Meu nome é: ' + nome + ' e meu e-mail é: ' + email)
// console.log('Minha data de nascimento: ', dataFormatada)
